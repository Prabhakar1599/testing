

import java.util.Scanner;

public class MyNumber {
	// 52037054 Naveen Goyal
	public static void main(String[] args) {
		// TODO Auto-generated method stub// 52037054 Naveen Goyal
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Number");
		double num= scan.nextDouble();// 52037054 Naveen Goyal
		double numRound = Math.round(num);
		System.out.println("Round value "+numRound);// 52037054 Naveen Goyal
		double numCeil = Math.ceil(num);
		System.out.println("Ceil Value "+numCeil);// 52037054 Naveen Goyal
		double numFloor = Math.floor(num);
		System.out.println("Floor Value "+numFloor);// 52037054 Naveen Goyal
		double numInt = (int)num;
		System.out.println("Integer Value "+numInt);// 52037054 Naveen Goyal
	}

}
