

public class Grader {
	int score;// 52037054 Naveen Goyal
	Grader(int score){
		this.score=score;
	}// 52037054 Naveen Goyal
	public String letterGrade(){
		if(score>=90) {
			return "A+";
		}// 52037054 Naveen Goyal
		else if(score>=85) {
			return "A";
		}// 52037054 Naveen Goyal
		else if(score>=80) {
			return "B+";
		}// 52037054 Naveen Goyal
		else if(score>=75) {
			return "B";
		}// 52037054 Naveen Goyal
		else if(score>=65) {
			return "C+";
		}
		else if(score>=60) {
			return "C";
		}
		else if(score>=55) {
			return "D+";
		}
		else if(score>=50) {
			return "D";
		}
		else{
			return "F";
		}
		
	}

}
