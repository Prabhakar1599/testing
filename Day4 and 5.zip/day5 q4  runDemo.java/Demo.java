package day5Q4;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub// 52037054 Naveen Goyal
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter Score");// 52037054 Naveen Goyal
		int score = scan.nextInt();
		if(score<0 || score>100) {// 52037054 Naveen Goyal
			System.out.println("Enter Valid score");
		}// 52037054 Naveen Goyal
		else {// 52037054 Naveen Goyal
			Grader g = new Grader(score);
			System.out.println("Grade is "+g.letterGrade());
		}

	}

}
