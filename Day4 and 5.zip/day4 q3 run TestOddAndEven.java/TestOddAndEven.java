


import java.util.Scanner;

public class TestOddAndEven {
	// 52037054 Naveen Goyal
	public static void main(String[] args) {
		String s;
		int n;
		Scanner scan= new Scanner(System.in);
		OddAndEven test = new OddAndEven();
		System.out.println("Enter a Number or Q to quit");
		s=scan.nextLine();
		// 52037054 Naveen Goyal
		// TODO Auto-generated method stub
		while(!s.equals("Q")) {
		n = Integer.parseInt(s);
		test.addNumber(n);
		System.out.println("Enter a Number or Q to quit");
		s = scan.nextLine();
		// 52037054 Naveen Goyal
		}
		// 52037054 Naveen Goyal
		System.out.println(test.toString());
			
		
		

	}

}
