
public class OddAndEven {
	// 52037054 Naveen Goyal
	int countOfOdd=0 ,countOfEven=0,n;
	
	void addNumber(int k) {
		n=k;
		if(n%2==0) {
			countOfEven++;
		}
		else {
			countOfOdd++;
		}
		// 52037054 Naveen Goyal
	}
	
	public String toString() {
		return ("Number of Odd: "+countOfOdd+", Number of Even : "+countOfEven);
		
	}

}
