

public  class PermanentEmployee extends Employee{
	double BasicSalary;
	double HRAPercent;
	double DAPercent;
	double PFPercent;
	double totalSalary;
	// 52037054 Naveen Goyal
	// 52037054 Naveen Goyal
	public PermanentEmployee(String eName, int eMobile, int eId,double BasicSalary,double HRAPercent,	double DAPercent,	double PFPercent) {
		super(eName, eMobile, eId);
		this.BasicSalary=BasicSalary;
		this.DAPercent=DAPercent;
		this.PFPercent=PFPercent;
		this.HRAPercent=HRAPercent;
		// TODO Auto-generated constructor stub
	}

	// 52037054 Naveen Goyal
	
	public void CalculateSal() {
		// TODO Auto-generated method stub
		PFPercent=(PFPercent*BasicSalary)/100;
		DAPercent=(DAPercent*BasicSalary)/100;
		HRAPercent=(HRAPercent*BasicSalary)/100;
		totalSalary = BasicSalary + DAPercent+ HRAPercent-PFPercent;
		// 52037054 Naveen Goyal
	}
	public double getSalary() {
		return totalSalary;
	}
	public double getPF() {
		return PFPercent;
	}// 52037054 Naveen Goyal


	
	
	

}
