

public  class TemporaryEmployee extends Employee {
	double HourlyWages;
	int HoursWorked;
	double totalSalary;
	// 52037054 Naveen Goyal
	public TemporaryEmployee(String eName, int eMobile, int eId, double HourlyWages, int HoursWorked) {
		super(eName, eMobile, eId);
		this.HourlyWages=HourlyWages;
		this.HoursWorked=HoursWorked;
		// TODO Auto-generated constructor stub
	}// 52037054 Naveen Goyal

	// 52037054 Naveen Goyal
	public void CalculateSal() {
		// TODO Auto-generated method stub
		totalSalary=HourlyWages*HoursWorked;		
	}// 52037054 Naveen Goyal
	
	public double getSalary() {
		return totalSalary;
	}

	

}
