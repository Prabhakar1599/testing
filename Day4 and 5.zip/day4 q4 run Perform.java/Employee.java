public  class Employee {
	
	String eName;// 52037054 Naveen Goyal
	int eMobile;
	int eId;// 52037054 Naveen Goyal
	
	public Employee(String eName, int eMobile, int eId) {
		this.eId=eId;
		this.eMobile=eMobile;
		this.eName=eName;
	}
	// 52037054 Naveen Goyal
	//public void CalculateSal(double BasicSalary,double HRAPercent,	double DAPercent,	double PFPercent);
	
//	public  void CalculateSal(double HourlyWages, int HoursWorked);

}
