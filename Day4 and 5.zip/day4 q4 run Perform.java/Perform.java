

import java.util.Scanner;

public class Perform {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Which Type of Employee's salary you want to calculate\n"
				+ "1. Permanent Employee\n"
				+ "2. TemporaryEmployee");
		int n = scan.nextInt();
		System.out.println("Enter Employee Name");
		scan.nextLine();
		String name= scan.nextLine();
		System.out.println("Enter Mobile Number");
		int mNo = scan.nextInt();
		System.out.println("Enter Employee ID");
		int id = scan.nextInt();
		switch(n) {
		case 1:
			System.out.println("Enter Basic Salary");
			double salary = scan.nextDouble();
			System.out.println("Enter HRA Percent");
			double HRA = scan.nextDouble();
			System.out.println("Enter DA Percent");
			double DA = scan.nextDouble();
			System.out.println("Enter PF percent");
			double PF = scan.nextDouble();
			PermanentEmployee p= new PermanentEmployee(name,mNo, id,salary,HRA,DA,PF);
			p.CalculateSal();
			System.out.println("\n Salary of "+p.eName+" is "+p.getSalary()+" and PF deduction is "+p.getPF());
			break;
		case 2:
			System.out.println("Enter Hourlywage");
			double hourly=scan.nextDouble();
			System.out.println("Enter total working hours");
			int hours = scan.nextInt();
			TemporaryEmployee t = new TemporaryEmployee (name,mNo,id,hourly,hours);
			t.CalculateSal();
			System.out.println("\n Salary of "+t.eName+" is "+t.getSalary());
			break;
			default:
				System.out.println("AH!!!!!!!!!! Wrong selection");
				
		}
		
		
		
		
		scan.close();
		

	}

}
