

public class Circle {
	double radius;
	double x,y;
	
	Circle(double rad){
		this.radius=rad;
	}
	
	double getArea() {
		double area ;
		area = Math.PI*radius*radius;
		return area;
	}
	void setCenter(double a, double b) {
		x=a;
		y=b;
	}
	
	double getPerimeter() {
		double perimeter;
		perimeter = 2* Math.PI* radius;
		return perimeter;
	}
	
	String checkInside(int v , int b) {
		if((v - x)*(v - x)+(b -y)*(b - y)<= radius * radius) {
			return "are in Circle";
		}
		else {
			return "are not in Circle";
		}
		
	}

}
