


import java.util.Scanner;
//52037054 Naveen Goyal
public class circleMain {// 52037054 Naveen Goyal
	// 52037054 Naveen Goyal
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double rad=0;

		Scanner scan = new Scanner (System.in);
		
		do {// 52037054 Naveen Goyal
			System.out.println("Enter the radius");
			rad = scan.nextDouble();// 52037054 Naveen Goyal
			Circle circle = new Circle(rad);
			if(rad<0) {
				System.exit(0);
			}
			System.out.println("Which Task you want to perform"
					+ "\n1. Find Area of circle"
					+ "\n2. Find Perimeter of circle"
					+ "\n3. Check whether given 2 points are in circle or not");
			int n = scan.nextInt();
			switch(n) {// 52037054 Naveen Goyal
			case 1:// 52037054 Naveen Goyal
				System.out.println("Perimeter is "+circle.getArea());
				break;// 52037054 Naveen Goyal
			case 2:// 52037054 Naveen Goyal
				System.out.println("Perimeter is "+circle.getPerimeter());
				break;// 52037054 Naveen Goyal
			case 3:
				System.out.println("Enter center point X , Y of circle");
				int x= scan.nextInt();
				int y =scan.nextInt();// 52037054 Naveen Goyal
				circle.setCenter(x, y);
				System.out.println("Enter point A, B that you want to check");
				int a= scan.nextInt();// 52037054 Naveen Goyal
				int b =scan.nextInt();
				System.out.println("Given points "+circle.checkInside(a,b));
				default:
					System.out.println("Wrong Selection!!! enter negetive radius to exit");
			}// 52037054 Naveen Goyal
		}while(true);// 52037054 Naveen Goyal
		
	}

}
